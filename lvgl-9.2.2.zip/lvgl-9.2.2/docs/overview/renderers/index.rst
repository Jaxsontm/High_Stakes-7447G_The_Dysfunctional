==================
Renderers and GPUs
==================

.. toctree::
    :maxdepth: 2

    sw
    sdl
    arm2d
    pxp
    stm32_dma2d
    vglite
    vg_lite
